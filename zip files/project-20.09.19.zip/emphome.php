<?php
include 'emplayout.php';
include 'footer.php';
?>