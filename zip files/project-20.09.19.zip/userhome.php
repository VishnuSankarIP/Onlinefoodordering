<?php
include 'user.php';
?>
<style type="text/css">
  td,th{
    padding:10px 10px 10px 10px;
    width:450px;
  }
  th{
    color:red;
    font-size: large;
  }
</style>
<!-- <div class="container">
<form  method="POST">
	<div class="col-75">
       <select id="category" name="txtcategory">
         <option>vegitarian</option>
        <option> non vegitarian</option>
        <option>not applicable</option>
       </select>
      </div>
	
    <div class="row">
      <div class="col-25">
        <label for="item"></label>
      </div>
      <div class="col-75">
        <input type="text" id="item" name="txtitem" placeholder="Item name">
      </div>
    </div>

    <div class="row">
      <input type="submit" value="Search" name="btnsubmit">
    </div>
</form>
</div> -->
<?php
include 'connection.php';
// if(isset($_REQUEST['btnsubmit']))
// {
// $category=$_REQUEST['txtcategory'];
// $item="%".$_REQUEST['txtitem']."%";
// echo "<script>location.href='search.php?cat=".$category."&item=".$item."'</script>";
// }
echo '<center><h1>Menu</h1></center>';
$q="select * from tblproduct order by product_name";
$result=mysqli_query($conn,$q);
echo "<br>";
echo "<table style='margin-left:350px;'><tr><th>Item</th><th>Rate</th></tr>";
while($row=mysqli_fetch_row($result))
{ 
  echo "<tr>";
  echo "<td>"."<a href='order.php?id=".$row[0]."'>"."$row[1]"."</a></td>";
  echo "<td>"."$row[2]"."</td>";
  echo "</tr>";
}
echo "</table>";
include 'footer.php';
?>