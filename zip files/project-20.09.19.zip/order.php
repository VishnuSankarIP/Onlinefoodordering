<?php
include 'user.php';
include 'connection.php';
?>
<div class="container">
  <form method="POST">
    <div class="row">
      <div class="col-25">
        <label for="q">Quantity</label>
      </div>
      <div class="col-75">
        <input type="text" id="q" name="txtq" required="required">
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Order Now" name="btnsubmit">
    </div>
    <div class="row">
      <input type="submit" value="Add New" name="btnadd">
    </div>
  </form>
</div>
<?php
$id=$_GET['id'];
$cid=$_SESSION['id'];
$quantity=$_REQUEST['txtq'];
if(isset($_REQUEST['btnsubmit']))
{
  $q="insert into tblorder_master(customer_id,order_date,total_amount,status) values($cid,(select sysdate),0,'ordered')";
  $s=mysqli_query($conn,$q);
  if($s)
  {
    $oid="select MAX(order_id) from tblorder_master";
    $q="select * from tblproduct where product_id=$id";
    $s=mysqli_query($conn,$q);
    $row=mysqli_fetch_array($s);
    $pid=$row[0];
    $rate=$row[2];
    $q="insert into tblorder_child(order_id,product_id,quantity,price) values($oid,$pid,'$quantity','$rate')";
    
  }
}
include 'footer.php';
?>
       