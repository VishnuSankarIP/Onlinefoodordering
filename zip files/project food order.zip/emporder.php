<?php
SESSION_START();
$id=$_SESSION['id'];
include 'connection.php';
include 'emplayout.php';
$q="select * from tblallocation where emp_id='$id'";
$s=mysqli_query($conn,$q);
echo "<table border=1><tr><th>Allocation Id</th><th>Order Id</th><th>Status</th></tr>";
while($row=mysqli_fetch_array($s))
{
  echo "<tr>";
  echo "<td>"."$row[0]"."</td>";
  echo "<td>"."$row[1]"."</td>";
  echo "<td>"."$row[3]"."</td>";
  echo "<td>"."<a href='delivered.php?oid=".$row[1]."'>Delivered</a></td>";
  echo "<td>"."<a href='ordercancel.php?oid=".$row[1]."'>Cancel</a></td>";
  
  echo "</tr>";
}
echo "</table>";
include 'footer.php';
?>