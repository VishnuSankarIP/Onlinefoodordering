<?php
include 'connection.php';
include 'admin.php';
echo "<br><h1>Order Details..</h1>";
$q="select * from tblorder_master";
$result=mysqli_query($conn,$q);
echo "<br>";
echo "<table border=1><tr><th>Order Id</th><th>Customer Id</th><th>Order Date</th><th>Total Amount</th>
<th>Status</th></tr>";
while($row=mysqli_fetch_row($result))
{ 
  echo "<tr>";
  echo "<td>"."$row[0]"."</td>";
  echo "<td>"."$row[1]"."</td>";
  echo "<td>"."$row[2]"."</td>";
  echo "<td>"."$row[3]"."</td>";
  echo "<td>"."$row[4]"."</td>";
  echo "<td>"."<a href='allocation.php?oid=".$row[0]."'>Allocate</a></td>";
  echo "</tr>";
}
echo "</table>";
?>
<?php
include 'footer.php';
?>
