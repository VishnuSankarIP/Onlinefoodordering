<?php
include 'connection.php';
include 'admin.php';
echo "<h3>FEEDBACK...</h3>";
$q="select * from tblfeedback ";
$result=mysqli_query($conn,$q);
echo "<br>";
echo "<table><tr><th>Payment Id</th><th>Order Id</th><th>Total Amount</th><th>Quantity</th>
</tr>";
while($row=mysqli_fetch_row($result))
{	
  echo "<tr>";
  echo "<td>".$row['0']."</td>";
  echo "<td>".$row['1']."</td>";
  echo "<td>".$row['2']."</td>";
  echo "</tr>";
}
echo "</table>";
include 'footer.php';
?>