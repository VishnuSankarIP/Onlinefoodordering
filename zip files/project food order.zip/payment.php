<?php
//SESSION_START();
//$uid=$_SESSION['id'];
 include 'connection.php';
  $oid=$_GET['id'];
  $q="select sum(price) from tblorder_child where order_id='$oid'";
  $t=mysqli_query($conn,$q);
$tot=mysqli_fetch_array($t);
$total=$tot[0];
?> 
<div class="container">
  <form method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col-25">
        <label for="no">Enter Card No.</label>    
      </div>
      <div class="col-75">
        <input type="text" id="no" name="txtno" required="required">
      </div>
    </div>
    <div class="row">
    <div class="col-25">
        <label for="edate">Expiry Date</label>
      </div>
      <div class="col-75">
        <input type="date" id="edate" name="txtdate" required="required">
      </div>
    </div>
    <div class="row">
    <div class="col-25">
        <label for="cvv">cvv</label>
      </div>
      <div class="col-75">
        <input type="text" id="cvv" name="txtcvv" required="required">
      </div>
    </div>
    <div class="row">
    <div class="col-25">
        <label for="amount">Amount</label>
      </div>
      <div class="row">
      <div class="col-75">
        <input type="text" id="amount" name="txtamount" required="required" 
              value="<?php echo $total;?>">
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Pay Now" name="btnsubmit">
    </div>
  </form>
</div>
<?php
if(isset($_REQUEST['btnsubmit']))
{
  $q="update tblorder_master set total_amount='$total' where order_id='$oid'";
  $s=mysqli_query($conn,$q);
  if($s)
  {
    echo"<script> succes </script>";
    $l="insert into tblview_payment(order_id,pay_amount,pay_type) values('$oid','$total','Online Transaction')";
   if(mysqli_query($conn,$l))
   {
    echo "<script>location.href='paymentdtls.php?id=".$oid."'</script>";
  }
  }
}
?>