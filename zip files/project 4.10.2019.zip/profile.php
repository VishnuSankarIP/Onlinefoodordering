<?php
include 'user.php';
include 'connection.php';
$q="select * from "