<?php
include 'connection.php';
$oid=$_GET['id'];
$q="select tblview_payment.*, tblorder_master.* from tblview_payment,tblorder_master 
where tblorder_master.order_id='$oid' and tblview_payment.order_id='$oid'";
$result=mysqli_query($conn,$q);
echo "<br>";
echo "<table border=1><tr><th>Payment Id</th><th>Order Id</th><th>Total Amount</th><th>Quantity</th>
</tr>";
while($row=mysqli_fetch_row($result))
{ 
  echo "<tr>";
  echo "<td>"."$row[0]"."</td>";
  echo "<td>"."$row[1]"."</td>";
  echo "<td>"."$row[2]"."</td>";

  
  
  echo "</tr>";
}
echo "</table>";
?>