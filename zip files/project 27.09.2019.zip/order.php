<?php
SESSION_START();
$cid=$_SESSION['uname'];
include 'user.php';
include 'connection.php';
?>
<div class="container">
  <form method="POST">
    <div class="row">
      <div class="col-25">
        <label for="q">Quantity</label>
      </div>
      <div class="col-75">
        <input type="text" id="q" name="txtq" required="required">
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Order Now" name="btnsubmit">
    </div>
    <div class="row">
      <input type="submit" value="Add New" name="btnadd">
    </div>
  </form>
</div>
<?php

if(isset($_REQUEST['btnsubmit']))
{
  $id=$_GET['id'];
$quantity=$_REQUEST['txtq'];
  $q="insert into tblorder_master(customer_id,order_date,total_amount,status) values('$cid',(select sysdate()),'0','ordered')";
  $s=mysqli_query($conn,$q);
  if($s)
  {
    $oid="select MAX(order_id) from tblorder_master";
    $q="select * from tblproduct where product_id=$id";
    $s=mysqli_query($conn,$q);
    $row=mysqli_fetch_array($s);
    $pid=$row[0];
    $rate=$row[2];
    $q="insert into tblorder_child(order_id,product_id,quantity,price) values((select MAX(order_id) from tblorder_master),'$pid','$quantity','$rate')";
    $s=mysqli_query($conn,$q);
    if($s)
    {
     // echo $q; 

      echo "<script>location.href='payment.php?id=".$oid."'</script>";
    }
   } 
   else
   {
    echo $q;
   }
}
include 'footer.php';
?>
       