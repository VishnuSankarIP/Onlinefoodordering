<div class="container">
  <form method="POST" enctype="multipart/form-data">
    <div class="row">
      <div class="col-25">
        <label for="no">Enter Card No.</label>
      </div>
      <div class="col-75">
        <input type="text" id="no" name="txtno" required="required">
      </div>
    </div>
    <div class="row">
    <div class="col-25">
        <label for="edate">Expiry Date</label>
      </div>
      <div class="col-75">
        <input type="date" id="edate" name="txtdate" required="required">
      </div>
    </div>
    <div class="row">
    <div class="col-25">
        <label for="cvv">cvv</label>
      </div>
      <div class="col-75">
        <input type="text" id="cvv" name="txtcvv" required="required">
      </div>
    </div>
    <div class="row">
    <div class="col-25">
        <label for="amount">Amount</label>
      </div>
      <div class="row">
      <div class="col-75">
        <input type="text" id="amount" name="txtamount" required="required">
      </div>
    </div>
    <div class="row">
      <input type="submit" value="Pay Now" name="btnsubmit">
    </div>
  </form>
</div>

<?php
include 'connection.php';
if(isset($_REQUEST['submit']))
{

  $oid=$_GET['id'];
  $total="select sum(price) from tblorder_child where order_id='$oid'";
  $q="update tblorder_master set 'total_amount'='$total' where order_id='$oid'";
  $s=mysqli_query($conn,$q);
  if($s)
  {
    
  }
}
?>